import { ConnectDB } from "./app/lib/DBConnect";


export function register(){
    ConnectDB();
}